---
name: Terra for EVORA
colors:
  surface: '#f7fbf0'
  surface-dim: '#d7dcd1'
  surface-bright: '#f7fbf0'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f1f5ea'
  surface-container: '#ebefe4'
  surface-container-high: '#e5eadf'
  surface-container-highest: '#e0e4d9'
  on-surface: '#181d16'
  on-surface-variant: '#414942'
  inverse-surface: '#2d322a'
  inverse-on-surface: '#eef2e7'
  outline: '#717971'
  outline-variant: '#c1c9bf'
  surface-tint: '#376847'
  primary: '#316342'
  on-primary: '#ffffff'
  primary-container: '#4a7c59'
  on-primary-container: '#e1ffe5'
  inverse-primary: '#9dd3aa'
  secondary: '#605e5a'
  on-secondary: '#ffffff'
  secondary-container: '#e6e2dc'
  on-secondary-container: '#666460'
  tertiary: '#6a572b'
  on-tertiary: '#ffffff'
  tertiary-container: '#846f41'
  on-tertiary-container: '#fff6ec'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#b9efc5'
  primary-fixed-dim: '#9dd3aa'
  on-primary-fixed: '#00210e'
  on-primary-fixed-variant: '#1e5031'
  secondary-fixed: '#e6e2dc'
  secondary-fixed-dim: '#c9c6c0'
  on-secondary-fixed: '#1c1c18'
  on-secondary-fixed-variant: '#484743'
  tertiary-fixed: '#fbdfa8'
  tertiary-fixed-dim: '#dec38e'
  on-tertiary-fixed: '#251a00'
  on-tertiary-fixed-variant: '#56441b'
  background: '#f7fbf0'
  on-background: '#181d16'
  surface-variant: '#e0e4d9'
  surface-cream: '#faf6f0'
  accent-amber: '#705c30'
  forest-action: '#4a7c59'
  moss-muted: '#8ba888'
  earth-text: '#2e3230'
typography:
  display-lg:
    fontFamily: Literata
    fontSize: 48px
    fontWeight: '700'
    lineHeight: 56px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Literata
    fontSize: 32px
    fontWeight: '600'
    lineHeight: 40px
  headline-lg-mobile:
    fontFamily: Literata
    fontSize: 28px
    fontWeight: '600'
    lineHeight: 36px
  headline-md:
    fontFamily: Literata
    fontSize: 24px
    fontWeight: '500'
    lineHeight: 32px
  body-lg:
    fontFamily: Nunito Sans
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Nunito Sans
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  label-lg:
    fontFamily: Nunito Sans
    fontSize: 14px
    fontWeight: '700'
    lineHeight: 20px
    letterSpacing: 0.01em
  label-md:
    fontFamily: Nunito Sans
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
  data-tabular:
    fontFamily: Nunito Sans
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  base: 8px
  gutter: 24px
  margin-mobile: 16px
  margin-desktop: 40px
  container-max: 1440px
---

## Brand & Style

The design system is built on the philosophy of **Rooted Warmth**, specifically evolved for the EVORA enterprise fleet platform. It bridges the gap between rugged industrial utility and modern SaaS sophistication. The aesthetic is **Modern-Organic**, prioritizing calm efficiency over high-energy tech tropes.

The target audience consists of fleet managers and logistics professionals who require a tool that reduces cognitive load during high-stakes decision-making. By utilizing earthy tones and soft, approachable geometry, the UI evokes stability, reliability, and human-centric enterprise management. The style avoids clinical sterility in favor of a workspace that feels like a natural extension of the physical environment.

## Colors

The palette is strictly earthy and desaturated. The **Primary Forest Green** serves as the core signal for interactive elements and brand presence. The **Background Cream** replaces pure white to prevent eye strain and maintain an organic feel.

For enterprise data density, neutrals are tinted with warm undertones to ensure harmony with the brand colors. Secondary actions and highlighting use the **Warm Amber** to provide contrast without introducing jarring "alert" hues. System status colors (Success, Warning, Error) should be muted to match the overall saturation levels of the primary palette.

## Typography

This design system employs a dual-font strategy to balance character with legibility. 

- **Literata** is used for headlines to provide a sophisticated, authoritative, and editorial feel. It grounds the platform in a "reliable publication" aesthetic.
- **Nunito Sans** is the workhorse for enterprise data. Its rounded terminals mirror the UI's organic shapes while maintaining high x-height for readability in complex data tables and fleet manifests.

For enterprise data density, use `label-md` for table headers and `data-tabular` for cell content to ensure maximum information density without sacrificing the soft brand voice.

## Layout & Spacing

The layout follows a **Fluid Grid** model with a maximum container width of 1440px. Enterprise dashboards utilize a 12-column grid with a generous 24px gutter to maintain the "breathable" quality essential to the brand.

- **Desktop:** 12 columns, 40px side margins.
- **Tablet:** 8 columns, 24px side margins.
- **Mobile:** 4 columns, 16px side margins.

Vertical rhythm is strictly maintained using 8px increments. Large-scale components like cards and hero sections should favor `space-xl` (32px) or `space-2xl` (48px) padding to reinforce the unhurried, calm narrative of the design system.

## Elevation & Depth

Hierarchy is primarily established through **Tonal Layering** rather than heavy shadows. The base layer is the warm cream background, with cards and containers using a slightly lighter or darker cream tone to create separation.

Where elevation is required for interactivity (e.g., modals, floating action buttons), use highly diffused, low-opacity shadows with a slight green tint (`rgba(46, 50, 48, 0.06)`). This prevents the UI from feeling "clinical." Avoid hard borders; if a stroke is necessary for accessibility in data-heavy views, use a low-opacity version of the primary green or a warm neutral.

## Shapes

The shape language is defined by **Soft Continuity**. Following the `ROUND_TWELVE` specification, the standard radius for buttons, input fields, and small containers is 12px. Larger components like cards and layout modules should scale to `rounded-lg` (16px) or `rounded-xl` (24px).

This significant rounding serves to soften the "industrial" nature of fleet management, making the software feel more like a modern lifestyle application and reducing the perceived complexity of enterprise workflows.

## Components

### Buttons
- **Primary:** Solid `#4a7c59` fill with white or high-contrast cream text. 12px border radius.
- **Secondary:** Surface-cream background with a thin `#4a7c59` border and matching text.
- **Ghost:** No fill/border, primary green text. Used for low-priority actions in tables.

### Cards
- **Standard:** Warm cream fill, 24px internal padding, 12px rounded corners. Use tonal borders (1px, 10% opacity neutral) for high-density dashboards.

### Inputs & Form Fields
- **Fields:** Soft cream background, 12px radius, 16px horizontal padding.
- **States:** Focus state uses a 2px outer glow in the primary green with a 50% opacity.

### Data Tables
- **Header:** Background uses a slightly darker cream tint; text is `label-md` in a warm neutral.
- **Rows:** Alternating tonal shifts (zebra striping) are preferred over hard lines.

### Fleet Specifics
- **Status Chips:** Use rounded-pill shapes with desaturated versions of status colors (e.g., sage for 'active', dusty gold for 'idle', terracotta for 'issue').